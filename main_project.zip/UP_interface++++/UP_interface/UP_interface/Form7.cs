﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UP_interface
{
    public partial class Form7 : Form
    {
        string ConnStr = @"Data Source=sql;Initial Catalog= up_piliguzov ;Integrated Security=True";
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "up_piliguzovDataSet9.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter2.Fill(this.up_piliguzovDataSet9.Сотрудники);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "up_piliguzovDataSet6.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter1.Fill(this.up_piliguzovDataSet6.Сотрудники);
       

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id_сотрудника = textBox1.Text.ToString();
            string Имя = textBox2.Text.ToString();
            string Логин = textBox3.Text.ToString();
            string Пароль = textBox5.Text.ToString();
            string IP = textBox6.Text.ToString();
            string Последняя_дата_входа = textBox4.Text.ToString();
            string Анализатор = textBox8.Text.ToString();
            string Должность = textBox7.Text.ToString();



            string ConnStr = @"Data Source=sql;Initial Catalog=up_piliguzov ;Integrated Security=True";

            SqlConnection dbConnection = new SqlConnection(ConnStr);
            dbConnection.Open();
            string query = "INSERT INTO Сотрудники VALUES ('" + id_сотрудника + "','" + Имя + "', '" + Логин + "','" + Пароль + "','" + IP + "','" + Последняя_дата_входа + "','" + Анализатор + "','" + Должность + "')";

            SqlCommand dbCommand = new SqlCommand(query, dbConnection);

            if (dbCommand.ExecuteNonQuery() != 1)

                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");

            else

                MessageBox.Show("Данные добавлены!", "Внимание!");

            dbConnection.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Проверяем количество выбранных строк
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Выберите одну строку для удаления!", "Сообщение!");
                return;
            }
            // Запомним выбранную строку
            int index = dataGridView1.SelectedRows[0].Index;

            //Проверим данные в таблице
            if (dataGridView1.Rows[index].Cells[0].Value == null)
            {
                MessageBox.Show("Не все данные введены!", "Сообщение!");
                return;
            }

            //Считаем данные
            string id = dataGridView1.Rows[index].Cells[0].Value.ToString();

            SqlConnection con = new SqlConnection(ConnStr);
            // Выполняем запрос к базе данных
            con.Open();//открываем соединение
            string SqlText = "DELETE FROM [Сотрудники] WHERE id_сотрудника=" + id;//строка запроса
            SqlCommand dbCommand = new SqlCommand(SqlText, con);//команда

            //Выполняем запрос
            if (dbCommand.ExecuteNonQuery() != 1)

                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");
            else
                MessageBox.Show("Данные удалены !", "Сообщение!");
            // Удаляем данные из таблицы в форме

            dataGridView1.Rows.RemoveAt(index);
            //Закрываем соединение с БД
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ConnStr = @"Data Source=sql;Initial Catalog= УП_pugin_med ;Integrated Security=True";
            SqlConnection dbConnection = new SqlConnection(ConnStr);
            dbConnection.Open();
            string query = "SELECT * FROM [Сотрудники]";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Сотрудники]");
            dataGridView1.DataSource = ds.Tables["[Сотрудники]"].DefaultView;
            dbConnection.Close();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string ConnStr = @"Data Source=sql;Initial Catalog= up_piliguzov ;Integrated Security=True";
            SqlConnection dbConnection = new SqlConnection(ConnStr);
            dbConnection.Open();
            string query = "SELECT * FROM [Сотрудники]";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Сотрудники]");
            dataGridView1.DataSource = ds.Tables["[Сотрудники]"].DefaultView;
            dbConnection.Close();
        }
    }
}


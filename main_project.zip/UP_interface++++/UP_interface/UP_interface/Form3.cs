﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UP_interface
{
    public partial class Form3 : Form
    {
        private int r;
        string ConnStr = @"Data Source=sql;Initial Catalog = 'up_piliguzov'; Integrated Security = True";
        public object MyClass { get; private set; }

        public Form3()
        {
            InitializeComponent();
            
        }
        private void FillАнализатор()
        {
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da.Fill(ds, "[Анализатор]");
            dataGridView1.DataSource = ds.Tables["[Анализатор]"].DefaultView;
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Анализатор = textBox1.Text.ToString();
            string Название = textBox2.Text.ToString();
            string Описание = textBox3.Text.ToString();




            string ConnStr = @"Data Source=sql;Initial Catalog=up_piliguzov ;Integrated Security=True";

            SqlConnection dbConnection = new SqlConnection(ConnStr);
            dbConnection.Open();
            string query = "INSERT INTO Анализатор VALUES ('" + Анализатор + "','" + Название + "', '" + Описание + "')";

            SqlCommand dbCommand = new SqlCommand(query, dbConnection);

            if (dbCommand.ExecuteNonQuery() != 1)

                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");

            else

                MessageBox.Show("Данные добавлены!", "Внимание!");

            dbConnection.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Проверяем количество выбранных строк
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Выберите одну строку для удаления!", "Сообщение!");
                return;
            }
            // Запомним выбранную строку
            int index = dataGridView1.SelectedRows[0].Index;

            //Проверим данные в таблице
            if (dataGridView1.Rows[index].Cells[0].Value == null)
            {
                MessageBox.Show("Не все данные введены!", "Сообщение!");
                return;
            }

            //Считаем данные
            string id = dataGridView1.Rows[index].Cells[0].Value.ToString();

            SqlConnection con = new SqlConnection(ConnStr);
            // Выполняем запрос к базе данных
            con.Open();//открываем соединение
            string SqlText = "DELETE FROM [Анализатор] WHERE Анализатор=" + id;//строка запроса
            SqlCommand dbCommand = new SqlCommand(SqlText, con);//команда

            //Выполняем запрос
            if (dbCommand.ExecuteNonQuery() != 1)

                MessageBox.Show("Ошибка выполнения запроса!", "Ошибка!");
            else
                MessageBox.Show("Данные удалены !", "Сообщение!");
            // Удаляем данные из таблицы в форме

            dataGridView1.Rows.RemoveAt(index);
            //Закрываем соединение с БД
            con.Close();

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "up_piliguzovDataSet.Анализатор". При необходимости она может быть перемещена или удалена.
            this.анализаторTableAdapter1.Fill(this.up_piliguzovDataSet.Анализатор);
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ConnStr = @"Data Source=sql;Initial Catalog= up_piliguzov ;Integrated Security=True";
            SqlConnection dbConnection = new SqlConnection(ConnStr);
            dbConnection.Open();
            string query = "SELECT * FROM [Анализатор]";
            SqlDataAdapter da = new SqlDataAdapter(query, ConnStr);
            DataSet ds = new DataSet();
            da.Fill(ds, "[Анализатор]");
            dataGridView1.DataSource = ds.Tables["[Анализатор]"].DefaultView;
            dbConnection.Close();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }
        public void MyExecuteNonQuery(string SqlText)
        {
            SqlConnection cn;
            SqlCommand cmd;

            cn = new SqlConnection(ConnStr);
            cn.Open();
            cmd = cn.CreateCommand();
            cmd.CommandText = SqlText;
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
            {
                if (r == 0)
                {
                    int index, n;
                    string Анализатор, Название, Описание;
                    n = dataGridView1.Rows.Count;
                    if (n == 1) return;
                    index = dataGridView1.CurrentRow.Index;
                    Анализатор = dataGridView1[0, index].Value.ToString();
                    Название = dataGridView1[1, index].Value.ToString();
                    Описание = dataGridView1[2, index].Value.ToString();
                    textBox1.Text = Анализатор;
                    textBox2.Text = Название;
                    textBox3.Text = Описание;
                    r = 1;
                }
                else if (r == 1)
                {
                    string SqlText = "update [Анализатор] set Анализатор = " + textBox1.Text + ", Название = \'" + textBox2.Text + "\', Описание = " + textBox3.Text + " where Анализатор = " + textBox1.Text;
                    MyExecuteNonQuery(SqlText);
                    FillАнализатор();
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    r = 0;
                }
            }
            //else if (MyClass.Должность == "lab")
                //MessageBox.Show("У вас недостаточно прав для редактирования таблицы.", "Внимание!");

        }
    }

}

﻿namespace UP_interface
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idсотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.услугиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.времявыполненияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.заказBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.up_piliguzovDataSet5 = new UP_interface.up_piliguzovDataSet5();
            this.заказBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_pugin_medDataSet = new UP_interface.УП_pugin_medDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.заказTableAdapter = new UP_interface.УП_pugin_medDataSetTableAdapters.ЗаказTableAdapter();
            this.button6 = new System.Windows.Forms.Button();
            this.up_piliguzovDataSet2 = new UP_interface.up_piliguzovDataSet2();
            this.заказBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.заказTableAdapter1 = new UP_interface.up_piliguzovDataSet2TableAdapters.ЗаказTableAdapter();
            this.up_piliguzovDataSet3 = new UP_interface.up_piliguzovDataSet3();
            this.заказBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.заказTableAdapter2 = new UP_interface.up_piliguzovDataSet3TableAdapters.ЗаказTableAdapter();
            this.up_piliguzovDataSet4 = new UP_interface.up_piliguzovDataSet4();
            this.заказBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.заказTableAdapter3 = new UP_interface.up_piliguzovDataSet4TableAdapters.ЗаказTableAdapter();
            this.заказTableAdapter4 = new UP_interface.up_piliguzovDataSet5TableAdapters.ЗаказTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(653, 390);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 48);
            this.button3.TabIndex = 23;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(514, 390);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 48);
            this.button2.TabIndex = 22;
            this.button2.Text = "Изменить";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(42, 343);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "ID сотрудника";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(96, 376);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Услуги";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(161, 376);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(146, 20);
            this.textBox3.TabIndex = 19;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(161, 343);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(146, 20);
            this.textBox2.TabIndex = 18;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(161, 309);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(146, 20);
            this.textBox1.TabIndex = 17;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(378, 390);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 48);
            this.button1.TabIndex = 16;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(76, 309);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "ID заказа";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idсотрудникаDataGridViewTextBoxColumn,
            this.услугиDataGridViewTextBoxColumn,
            this.статусзаказаDataGridViewTextBoxColumn,
            this.времявыполненияDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.заказBindingSource4;
            this.dataGridView1.Location = new System.Drawing.Point(44, 135);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(453, 150);
            this.dataGridView1.TabIndex = 14;
            // 
            // idсотрудникаDataGridViewTextBoxColumn
            // 
            this.idсотрудникаDataGridViewTextBoxColumn.DataPropertyName = "id_сотрудника";
            this.idсотрудникаDataGridViewTextBoxColumn.HeaderText = "id_сотрудника";
            this.idсотрудникаDataGridViewTextBoxColumn.Name = "idсотрудникаDataGridViewTextBoxColumn";
            // 
            // услугиDataGridViewTextBoxColumn
            // 
            this.услугиDataGridViewTextBoxColumn.DataPropertyName = "Услуги";
            this.услугиDataGridViewTextBoxColumn.HeaderText = "Услуги";
            this.услугиDataGridViewTextBoxColumn.Name = "услугиDataGridViewTextBoxColumn";
            // 
            // статусзаказаDataGridViewTextBoxColumn
            // 
            this.статусзаказаDataGridViewTextBoxColumn.DataPropertyName = "Статус_заказа";
            this.статусзаказаDataGridViewTextBoxColumn.HeaderText = "Статус_заказа";
            this.статусзаказаDataGridViewTextBoxColumn.Name = "статусзаказаDataGridViewTextBoxColumn";
            // 
            // времявыполненияDataGridViewTextBoxColumn
            // 
            this.времявыполненияDataGridViewTextBoxColumn.DataPropertyName = "Время_выполнения";
            this.времявыполненияDataGridViewTextBoxColumn.HeaderText = "Время_выполнения";
            this.времявыполненияDataGridViewTextBoxColumn.Name = "времявыполненияDataGridViewTextBoxColumn";
            // 
            // заказBindingSource4
            // 
            this.заказBindingSource4.DataMember = "Заказ";
            this.заказBindingSource4.DataSource = this.up_piliguzovDataSet5;
            // 
            // up_piliguzovDataSet5
            // 
            this.up_piliguzovDataSet5.DataSetName = "up_piliguzovDataSet5";
            this.up_piliguzovDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // заказBindingSource
            // 
            this.заказBindingSource.DataMember = "Заказ";
            this.заказBindingSource.DataSource = this.уП_pugin_medDataSet;
            // 
            // уП_pugin_medDataSet
            // 
            this.уП_pugin_medDataSet.DataSetName = "УП_pugin_medDataSet";
            this.уП_pugin_medDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(37, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "Заказ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(333, 344);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 16);
            this.label5.TabIndex = 27;
            this.label5.Text = "Время выполнения";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(487, 343);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(146, 20);
            this.textBox4.TabIndex = 26;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(486, 309);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(146, 20);
            this.textBox5.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(364, 310);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 16);
            this.label6.TabIndex = 24;
            this.label6.Text = "Статус заказа";
            // 
            // заказTableAdapter
            // 
            this.заказTableAdapter.ClearBeforeFill = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Location = new System.Drawing.Point(593, 66);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 33);
            this.button6.TabIndex = 28;
            this.button6.Text = "<Выйти";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // up_piliguzovDataSet2
            // 
            this.up_piliguzovDataSet2.DataSetName = "up_piliguzovDataSet2";
            this.up_piliguzovDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // заказBindingSource1
            // 
            this.заказBindingSource1.DataMember = "Заказ";
            this.заказBindingSource1.DataSource = this.up_piliguzovDataSet2;
            // 
            // заказTableAdapter1
            // 
            this.заказTableAdapter1.ClearBeforeFill = true;
            // 
            // up_piliguzovDataSet3
            // 
            this.up_piliguzovDataSet3.DataSetName = "up_piliguzovDataSet3";
            this.up_piliguzovDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // заказBindingSource2
            // 
            this.заказBindingSource2.DataMember = "Заказ";
            this.заказBindingSource2.DataSource = this.up_piliguzovDataSet3;
            // 
            // заказTableAdapter2
            // 
            this.заказTableAdapter2.ClearBeforeFill = true;
            // 
            // up_piliguzovDataSet4
            // 
            this.up_piliguzovDataSet4.DataSetName = "up_piliguzovDataSet4";
            this.up_piliguzovDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // заказBindingSource3
            // 
            this.заказBindingSource3.DataMember = "Заказ";
            this.заказBindingSource3.DataSource = this.up_piliguzovDataSet4;
            // 
            // заказTableAdapter3
            // 
            this.заказTableAdapter3.ClearBeforeFill = true;
            // 
            // заказTableAdapter4
            // 
            this.заказTableAdapter4.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(653, 336);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(135, 48);
            this.button4.TabIndex = 29;
            this.button4.Text = "Обновление";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label6;
        private УП_pugin_medDataSet уП_pugin_medDataSet;
        private System.Windows.Forms.BindingSource заказBindingSource;
        private УП_pugin_medDataSetTableAdapters.ЗаказTableAdapter заказTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idсотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn услугиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn времявыполненияDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button6;
        private up_piliguzovDataSet2 up_piliguzovDataSet2;
        private System.Windows.Forms.BindingSource заказBindingSource1;
        private up_piliguzovDataSet2TableAdapters.ЗаказTableAdapter заказTableAdapter1;
        private up_piliguzovDataSet3 up_piliguzovDataSet3;
        private System.Windows.Forms.BindingSource заказBindingSource2;
        private up_piliguzovDataSet3TableAdapters.ЗаказTableAdapter заказTableAdapter2;
        private up_piliguzovDataSet4 up_piliguzovDataSet4;
        private System.Windows.Forms.BindingSource заказBindingSource3;
        private up_piliguzovDataSet4TableAdapters.ЗаказTableAdapter заказTableAdapter3;
        private up_piliguzovDataSet5 up_piliguzovDataSet5;
        private System.Windows.Forms.BindingSource заказBindingSource4;
        private up_piliguzovDataSet5TableAdapters.ЗаказTableAdapter заказTableAdapter4;
        private System.Windows.Forms.Button button4;
    }
}
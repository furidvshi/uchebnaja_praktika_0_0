﻿namespace UP_interface
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.услугаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.оказаннаяуслугаBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.up_piliguzovDataSet1 = new UP_interface.up_piliguzovDataSet1();
            this.оказаннаяуслугаBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.уП_pugin_medDataSet9 = new UP_interface.УП_pugin_medDataSet9();
            this.оказаннаяуслугаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.уП_pugin_medDataSet1 = new UP_interface.УП_pugin_medDataSet1();
            this.label1 = new System.Windows.Forms.Label();
            this.уП_pugin_medDataSet = new UP_interface.УП_pugin_medDataSet();
            this.оказанная_услугаTableAdapter = new UP_interface.УП_pugin_medDataSet1TableAdapters.Оказанная_услугаTableAdapter();
            this.оказанная_услугаTableAdapter1 = new UP_interface.УП_pugin_medDataSet9TableAdapters.Оказанная_услугаTableAdapter();
            this.button6 = new System.Windows.Forms.Button();
            this.оказанная_услугаTableAdapter2 = new UP_interface.up_piliguzovDataSet1TableAdapters.Оказанная_услугаTableAdapter();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказаннаяуслугаBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказаннаяуслугаBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказаннаяуслугаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(322, 258);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 48);
            this.button3.TabIndex = 23;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(459, 312);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 48);
            this.button2.TabIndex = 22;
            this.button2.Text = "Изменить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(371, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Цена";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(432, 166);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(146, 20);
            this.textBox2.TabIndex = 18;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(432, 132);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(146, 20);
            this.textBox1.TabIndex = 17;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(459, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 48);
            this.button1.TabIndex = 16;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(356, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "Услуга";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.услугаDataGridViewTextBoxColumn,
            this.ценаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.оказаннаяуслугаBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(47, 124);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(244, 182);
            this.dataGridView1.TabIndex = 14;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // услугаDataGridViewTextBoxColumn
            // 
            this.услугаDataGridViewTextBoxColumn.DataPropertyName = "Услуга";
            this.услугаDataGridViewTextBoxColumn.HeaderText = "Услуга";
            this.услугаDataGridViewTextBoxColumn.Name = "услугаDataGridViewTextBoxColumn";
            // 
            // ценаDataGridViewTextBoxColumn
            // 
            this.ценаDataGridViewTextBoxColumn.DataPropertyName = "Цена";
            this.ценаDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn.Name = "ценаDataGridViewTextBoxColumn";
            // 
            // оказаннаяуслугаBindingSource2
            // 
            this.оказаннаяуслугаBindingSource2.DataMember = "Оказанная_услуга";
            this.оказаннаяуслугаBindingSource2.DataSource = this.up_piliguzovDataSet1;
            // 
            // up_piliguzovDataSet1
            // 
            this.up_piliguzovDataSet1.DataSetName = "up_piliguzovDataSet1";
            this.up_piliguzovDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // оказаннаяуслугаBindingSource1
            // 
            this.оказаннаяуслугаBindingSource1.DataMember = "Оказанная_услуга";
            this.оказаннаяуслугаBindingSource1.DataSource = this.уП_pugin_medDataSet9;
            // 
            // уП_pugin_medDataSet9
            // 
            this.уП_pugin_medDataSet9.DataSetName = "УП_pugin_medDataSet9";
            this.уП_pugin_medDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // оказаннаяуслугаBindingSource
            // 
            this.оказаннаяуслугаBindingSource.DataMember = "Оказанная_услуга";
            this.оказаннаяуслугаBindingSource.DataSource = this.уП_pugin_medDataSet1;
            // 
            // уП_pugin_medDataSet1
            // 
            this.уП_pugin_medDataSet1.DataSetName = "УП_pugin_medDataSet1";
            this.уП_pugin_medDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(40, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "Услуги";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // уП_pugin_medDataSet
            // 
            this.уП_pugin_medDataSet.DataSetName = "УП_pugin_medDataSet";
            this.уП_pugin_medDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // оказанная_услугаTableAdapter
            // 
            this.оказанная_услугаTableAdapter.ClearBeforeFill = true;
            // 
            // оказанная_услугаTableAdapter1
            // 
            this.оказанная_услугаTableAdapter1.ClearBeforeFill = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Location = new System.Drawing.Point(486, 59);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 33);
            this.button6.TabIndex = 24;
            this.button6.Text = "<Выйти";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // оказанная_услугаTableAdapter2
            // 
            this.оказанная_услугаTableAdapter2.ClearBeforeFill = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(322, 312);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(119, 48);
            this.button4.TabIndex = 25;
            this.button4.Text = "Обновить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 450);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказаннаяуслугаBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.up_piliguzovDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказаннаяуслугаBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказаннаяуслугаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уП_pugin_medDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private УП_pugin_medDataSet уП_pugin_medDataSet;
        private УП_pugin_medDataSet1 уП_pugin_medDataSet1;
        private System.Windows.Forms.BindingSource оказаннаяуслугаBindingSource;
        private УП_pugin_medDataSet1TableAdapters.Оказанная_услугаTableAdapter оказанная_услугаTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn услугаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn;
        private УП_pugin_medDataSet9 уП_pugin_medDataSet9;
        private System.Windows.Forms.BindingSource оказаннаяуслугаBindingSource1;
        private УП_pugin_medDataSet9TableAdapters.Оказанная_услугаTableAdapter оказанная_услугаTableAdapter1;
        private System.Windows.Forms.Button button6;
        private up_piliguzovDataSet1 up_piliguzovDataSet1;
        private System.Windows.Forms.BindingSource оказаннаяуслугаBindingSource2;
        private up_piliguzovDataSet1TableAdapters.Оказанная_услугаTableAdapter оказанная_услугаTableAdapter2;
        private System.Windows.Forms.Button button4;
    }
}